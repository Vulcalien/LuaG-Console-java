-- For Documentation, see 'https://github.com/Vulcalien/LuaG-Console/wiki'

function init()

end

function tick()

end
